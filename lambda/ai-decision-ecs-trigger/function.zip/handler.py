"""
Lambda Function to Trigger ECS Task for AI Decision Workflows
Supports all 6 workflows: daily_learning, hourly_news_analysis, daily_summary, trading_decision, weekly_report, portfolio_snapshot
"""

import json
import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# ECS Configuration
ECS_CLUSTER = os.environ.get('ECS_CLUSTER', 'ai-stock-war-cluster')
TASK_DEFINITION = os.environ.get('TASK_DEFINITION', 'ai-decision-service')
SUBNETS = os.environ.get('SUBNETS', 'subnet-04fa1412b6915005b,subnet-00cf6fe01544e3d35').split(',')
SECURITY_GROUPS = os.environ.get('SECURITY_GROUPS', 'sg-030a73aaeff1f852d').split(',')
ASSIGN_PUBLIC_IP = os.environ.get('ASSIGN_PUBLIC_IP', 'DISABLED')

# Initialize ECS client
ecs_client = boto3.client('ecs', region_name='us-east-1')


def lambda_handler(event, context):
    """
    Lambda handler to trigger ECS task

    Event structure:
    {
        "workflow": "trading_decision",  # Required: workflow name
        "agent_id": "all"                # Optional: default "all"
    }
    """
    try:
        # Parse event
        workflow = event.get('workflow')
        agent_id = event.get('agent_id', 'all')

        if not workflow:
            raise ValueError("Missing required parameter: workflow")

        # Validate workflow
        valid_workflows = [
            'daily_learning',
            'hourly_news_analysis',
            'daily_summary',
            'trading_decision',
            'weekly_report',
            'portfolio_snapshot'
        ]

        if workflow not in valid_workflows:
            raise ValueError(f"Invalid workflow: {workflow}. Must be one of {valid_workflows}")

        logger.info(f"Triggering ECS task for workflow={workflow}, agent_id={agent_id}")

        # Run ECS task
        response = ecs_client.run_task(
            cluster=ECS_CLUSTER,
            taskDefinition=TASK_DEFINITION,
            launchType='FARGATE',
            networkConfiguration={
                'awsvpcConfiguration': {
                    'subnets': SUBNETS,
                    'securityGroups': SECURITY_GROUPS,
                    'assignPublicIp': ASSIGN_PUBLIC_IP
                }
            },
            overrides={
                'containerOverrides': [
                    {
                        'name': 'ai-decision',
                        'command': [
                            '--workflow', workflow,
                            '--agent_id', agent_id,
                            '--log-level', 'INFO',
                            '--log-format', 'json'
                        ]
                    }
                ]
            }
        )

        # Extract task information
        tasks = response.get('tasks', [])
        failures = response.get('failures', [])

        if failures:
            logger.error(f"ECS task failures: {failures}")
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'success': False,
                    'message': 'Failed to start ECS task',
                    'failures': failures
                })
            }

        if tasks:
            task_arn = tasks[0]['taskArn']
            task_id = task_arn.split('/')[-1]

            logger.info(f"ECS task started successfully: {task_id}")

            return {
                'statusCode': 200,
                'body': json.dumps({
                    'success': True,
                    'message': 'ECS task started successfully',
                    'workflow': workflow,
                    'agent_id': agent_id,
                    'task_arn': task_arn,
                    'task_id': task_id
                })
            }
        else:
            logger.error("No tasks started and no failures reported")
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'success': False,
                    'message': 'Unknown error: no tasks started'
                })
            }

    except Exception as e:
        logger.error(f"Error triggering ECS task: {e}", exc_info=True)
        return {
            'statusCode': 500,
            'body': json.dumps({
                'success': False,
                'message': str(e)
            })
        }
